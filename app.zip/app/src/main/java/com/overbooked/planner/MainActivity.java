package com.overbooked.planner;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.ContentValues;
import android.database.Cursor;
import android.provider.CalendarContract;
import android.content.ContentUris;
import android.webkit.JavascriptInterface;
import java.util.TimeZone;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
  private WebView webView;
  private static final String RELEASE_API =
      "https://api.github.com/repos/fafo-wifey/Overbooked/releases/latest";

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    webView = new WebView(this);
    webView.setWebViewClient(new WebViewClient());
    webView.addJavascriptInterface(new CalendarBridge(), "OverbookedCalendar");
    webView.setWebChromeClient(new WebChromeClient());
    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowFileAccessFromFileURLs(false);
    settings.setAllowUniversalAccessFromFileURLs(false);
    setContentView(webView);
    webView.loadUrl("file:///android_asset/index.html");
    checkForUpdates();
  }

  private static final int CALENDAR_PERMISSION_REQUEST = 184;
  private boolean calendarAllowed() {
    return checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
        && checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED;
  }
  private void sendCalendarResult(String method, JSONObject payload) {
    runOnUiThread(() -> {
      if (webView != null) webView.evaluateJavascript("window." + method + "(" + payload.toString() + ")", null);
    });
  }
  @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
    super.onRequestPermissionsResult(requestCode, permissions, results);
    if (requestCode == CALENDAR_PERMISSION_REQUEST) {
      JSONObject response = new JSONObject();
      try { response.put("granted", calendarAllowed()); } catch (Exception ignored) {}
      sendCalendarResult("calendarPermissionResult", response);
    }
  }
  public class CalendarBridge {
    @JavascriptInterface public void requestPermission() {
      runOnUiThread(() -> {
        if (calendarAllowed()) {
          JSONObject o = new JSONObject();
          try { o.put("granted", true); } catch (Exception ignored) {}
          sendCalendarResult("calendarPermissionResult", o);
        } else requestPermissions(new String[]{Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR}, CALENDAR_PERMISSION_REQUEST);
      });
    }
    @JavascriptInterface public void listCalendars() {
      new Thread(() -> {
        JSONObject result = new JSONObject(); JSONArray calendars = new JSONArray();
        try {
          result.put("granted", calendarAllowed());
          if (calendarAllowed()) try (Cursor c = getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,
              new String[]{CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                  CalendarContract.Calendars.ACCOUNT_TYPE, CalendarContract.Calendars.VISIBLE, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL},
              CalendarContract.Calendars.VISIBLE + "=1", null, null)) {
            if (c != null) while (c.moveToNext()) {
              JSONObject o = new JSONObject();o.put("id",c.getLong(0));o.put("name",c.getString(1));
              o.put("accountType",c.getString(2));o.put("writable",c.getInt(4)>=CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR);
              calendars.put(o);
            }
          }
          result.put("calendars",calendars);
        } catch (Exception e) {try {result.put("error",e.getMessage());}catch(Exception ignored){}}
        sendCalendarResult("calendarCalendarsResult",result);
      }).start();
    }
    @JavascriptInterface public void listEvents(String ids) {
      new Thread(() -> {
        JSONObject result = new JSONObject();JSONArray items = new JSONArray();
        try {
          if (!calendarAllowed()) throw new SecurityException("Calendar permission needed");
          JSONArray selected = new JSONArray(ids); java.util.HashSet<Long> wanted = new java.util.HashSet<>();
          for(int i=0;i<selected.length();i++)wanted.add(selected.getLong(i));
          long start=System.currentTimeMillis()-30L*86400000L, end=System.currentTimeMillis()+365L*86400000L;
          android.net.Uri uri=CalendarContract.Instances.CONTENT_URI.buildUpon().appendPath(Long.toString(start)).appendPath(Long.toString(end)).build();
          try(Cursor c=getContentResolver().query(uri,new String[]{CalendarContract.Instances.EVENT_ID,CalendarContract.Instances.CALENDAR_ID,
              CalendarContract.Instances.TITLE,CalendarContract.Instances.BEGIN,CalendarContract.Instances.END,CalendarContract.Instances.ALL_DAY},null,null,null)) {
            if(c!=null)while(c.moveToNext()) {
              if(!wanted.contains(c.getLong(1)))continue;
              JSONObject o=new JSONObject();o.put("eventId",c.getLong(0));o.put("calendarId",c.getLong(1));
              o.put("title",c.getString(2));o.put("start",c.getLong(3));o.put("end",c.getLong(4));
              o.put("allDay",c.getInt(5)!=0);items.put(o);
            }
          }
          result.put("events",items);
        }catch(Exception e){try{result.put("error",e.getMessage());}catch(Exception ignored){}}
        sendCalendarResult("calendarEventsResult",result);
      }).start();
    }
    @JavascriptInterface public void saveEvent(String json) {
      new Thread(() -> {
        JSONObject response=new JSONObject();
        try {
          if(!calendarAllowed())throw new SecurityException("Calendar permission needed");
          JSONObject data=new JSONObject(json);long calendarId=data.getLong("calendarId");
          long start=data.getLong("start"),end=data.getLong("end");
          if(end<=start)throw new IllegalArgumentException("End must be after start");
          ContentValues values=new ContentValues();values.put(CalendarContract.Events.TITLE,data.getString("title"));
          values.put(CalendarContract.Events.DTSTART,start);values.put(CalendarContract.Events.DTEND,end);
          values.put(CalendarContract.Events.EVENT_TIMEZONE,TimeZone.getDefault().getID());
          long id=data.optLong("eventId",-1);
          if(id>0) {
            int updated=getContentResolver().update(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,id),values,
                CalendarContract.Events.CALENDAR_ID+"=?",new String[]{Long.toString(calendarId)});
            if(updated!=1)throw new IllegalStateException("Calendar event could not be updated");
          }else{
            values.put(CalendarContract.Events.CALENDAR_ID,calendarId);
            Uri inserted=getContentResolver().insert(CalendarContract.Events.CONTENT_URI,values);
            if(inserted==null)throw new IllegalStateException("Calendar event could not be created");
            id=ContentUris.parseId(inserted);
          }
          response.put("ok",true);response.put("eventId",id);
        }catch(Exception e){try{response.put("error",e.getMessage());}catch(Exception ignored){}}
        try{response.put("localId",new JSONObject(json).optString("localId"));}catch(Exception ignored){}
        sendCalendarResult("calendarSaveResult",response);
      }).start();
    }
    @JavascriptInterface public void deleteEvent(long id,long calendarId,String localId) {
      new Thread(() -> {
        JSONObject response=new JSONObject();
        try {
          if(!calendarAllowed())throw new SecurityException("Calendar permission needed");
          int count=getContentResolver().delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,id),
              CalendarContract.Events.CALENDAR_ID+"=?",new String[]{Long.toString(calendarId)});
          if(count!=1)throw new IllegalStateException("Calendar event not found");
          response.put("ok",true);
        }catch(Exception e){try{response.put("error",e.getMessage());}catch(Exception ignored){}}
        try{response.put("localId",localId);}catch(Exception ignored){}
        sendCalendarResult("calendarDeleteResult",response);
      }).start();
    }
  }

  private int[] parts(String version) {
    String cleaned = version.replaceFirst("^[vV]", "").split("[-+]")[0];
    String[] bits = cleaned.split("\\.");
    int[] out = new int[3];
    for (int i = 0; i < out.length && i < bits.length; i++) {
      try { out[i] = Integer.parseInt(bits[i]); } catch (NumberFormatException ignored) {}
    }
    return out;
  }

  private boolean isNewer(String latest, String current) {
    int[] a = parts(latest), b = parts(current);
    for (int i = 0; i < 3; i++) {
      if (a[i] != b[i]) return a[i] > b[i];
    }
    return false;
  }

  private void checkForUpdates() {
    new Thread(() -> {
      HttpURLConnection connection = null;
      try {
        connection = (HttpURLConnection) new URL(RELEASE_API).openConnection();
        connection.setConnectTimeout(7000);
        connection.setReadTimeout(7000);
        connection.setRequestProperty("Accept", "application/vnd.github+json");
        connection.setRequestProperty("User-Agent", "Overbooked-Android");
        if (connection.getResponseCode() != 200) return;
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        try (InputStream in = connection.getInputStream()) {
          byte[] buffer = new byte[4096];
          int n;
          while ((n = in.read(buffer)) != -1) data.write(buffer, 0, n);
        }
        JSONObject release = new JSONObject(data.toString("UTF-8"));
        String latest = release.optString("tag_name", "");
        String current = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        if (!isNewer(latest, current)) return;
        JSONArray assets = release.optJSONArray("assets");
        String download = null;
        if (assets != null) {
          for (int i = 0; i < assets.length(); i++) {
            JSONObject asset = assets.optJSONObject(i);
            if (asset != null && asset.optString("name", "").toLowerCase().endsWith(".apk")) {
              download = asset.optString("browser_download_url", "");
              break;
            }
          }
        }
        if (download == null || !download.startsWith("https://")) return;
        final String url = download;
        runOnUiThread(() -> {
          if (isFinishing() || isDestroyed()) return;
          new AlertDialog.Builder(this)
              .setTitle("Overbooked update available")
              .setMessage("Version " + latest + " is available. Download the update?")
              .setNegativeButton("Later", null)
              .setPositiveButton("Update now", (dialog, which) ->
                  startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))))
              .show();
        });
      } catch (Exception ignored) {
        // Offline or no published release: app remains fully usable.
      } finally {
        if (connection != null) connection.disconnect();
      }
    }).start();
  }

  @Override public void onBackPressed() {
    if (webView != null && webView.canGoBack()) webView.goBack();
    else super.onBackPressed();
  }
  @Override protected void onDestroy() {
    if (webView != null) webView.destroy();
    super.onDestroy();
  }
}
