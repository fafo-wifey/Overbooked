package com.overbooked.planner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
  private WebView webView;
  private static final String RELEASE_API =
      "https://api.github.com/repos/fafo-wifey/Overbooked/releases/latest";

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    webView = new WebView(this);
    webView.setWebViewClient(new WebViewClient());
    webView.setWebChromeClient(new WebChromeClient());
    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowFileAccessFromFileURLs(false);
    settings.setAllowUniversalAccessFromFileURLs(false);
    setContentView(webView);
    webView.loadUrl("file:///android_asset/index.html");
    checkForUpdates();
  }

  private int[] parts(String version) {
    String cleaned = version.replaceFirst("^[vV]", "").split("[-+]")[0];
    String[] bits = cleaned.split("\\.");
    int[] out = new int[3];
    for (int i = 0; i < out.length && i < bits.length; i++) {
      try { out[i] = Integer.parseInt(bits[i]); } catch (NumberFormatException ignored) {}
    }
    return out;
  }

  private boolean isNewer(String latest, String current) {
    int[] a = parts(latest), b = parts(current);
    for (int i = 0; i < 3; i++) {
      if (a[i] != b[i]) return a[i] > b[i];
    }
    return false;
  }

  private void checkForUpdates() {
    new Thread(() -> {
      HttpURLConnection connection = null;
      try {
        connection = (HttpURLConnection) new URL(RELEASE_API).openConnection();
        connection.setConnectTimeout(7000);
        connection.setReadTimeout(7000);
        connection.setRequestProperty("Accept", "application/vnd.github+json");
        connection.setRequestProperty("User-Agent", "Overbooked-Android");
        if (connection.getResponseCode() != 200) return;
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        try (InputStream in = connection.getInputStream()) {
          byte[] buffer = new byte[4096];
          int n;
          while ((n = in.read(buffer)) != -1) data.write(buffer, 0, n);
        }
        JSONObject release = new JSONObject(data.toString("UTF-8"));
        String latest = release.optString("tag_name", "");
        String current = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        if (!isNewer(latest, current)) return;
        JSONArray assets = release.optJSONArray("assets");
        String download = null;
        if (assets != null) {
          for (int i = 0; i < assets.length(); i++) {
            JSONObject asset = assets.optJSONObject(i);
            if (asset != null && asset.optString("name", "").toLowerCase().endsWith(".apk")) {
              download = asset.optString("browser_download_url", "");
              break;
            }
          }
        }
        if (download == null || !download.startsWith("https://")) return;
        final String url = download;
        runOnUiThread(() -> {
          if (isFinishing() || isDestroyed()) return;
          new AlertDialog.Builder(this)
              .setTitle("Overbooked update available")
              .setMessage("Version " + latest + " is available. Download the update?")
              .setNegativeButton("Later", null)
              .setPositiveButton("Update now", (dialog, which) ->
                  startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))))
              .show();
        });
      } catch (Exception ignored) {
        // Offline or no published release: app remains fully usable.
      } finally {
        if (connection != null) connection.disconnect();
      }
    }).start();
  }

  @Override public void onBackPressed() {
    if (webView != null && webView.canGoBack()) webView.goBack();
    else super.onBackPressed();
  }
  @Override protected void onDestroy() {
    if (webView != null) webView.destroy();
    super.onDestroy();
  }
}
