const $=id=>document.getElementById(id);const themes={'Pastel Kawaii':['#fff0fa','#f5dff3','#bd79b6','#49364b'],'Industrial Dark':['#1c2228','#303941','#ffad5b','#f6f7f9'],'Strawberry Sweet':['#fff2ec','#ffe0e5','#df6988','#603747'],'Pastel Goth':['#251d35','#382b4a','#d5a9f7','#fff0ff'],'Celestial Forest':['#172b28','#25453a','#d8bc78','#f2f3dc'],'Cyberpunk Neon':['#111023','#252044','#2ee7e0','#f9ecff'],'Cozy Cottage':['#f3f0df','#e1e8d6','#779b6e','#344537'],'Midnight Luxury':['#151515','#292929','#d7b56d','#fff9e9'],'Retro Pixel':['#27203e','#47385f','#f19ed3','#f5e9ff'],'Ocean Dream':['#102e42','#1b4a60','#71d5e4','#f0fbff']};const load=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};const save=(k,v)=>localStorage.setItem(k,JSON.stringify(v));let events=load('events',[]),palette=load('palette',{}),theme=load('theme','Pastel Goth'),faves=load('faves',['Pastel Goth','Strawberry Sweet','Celestial Forest']);function tab(id){document.querySelectorAll('main section').forEach(s=>s.classList.toggle('hidden',s.id!==id));document.querySelectorAll('nav button').forEach((b,i)=>b.classList.toggle('active',['home','calendar','work','checkin','themes'][i]===id));render()}function isoDay(d){return new Date(d).toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}function weekStart(d){const x=new Date(d);x.setHours(0,0,0,0);x.setDate(x.getDate()-(x.getDay()+6)%7);return x}function inWeek(d){let a=weekStart(new Date()),b=new Date(a);b.setDate(b.getDate()+7);return new Date(d)>=a&&new Date(d)<b}function weight(e){return Number(e.hours)*Number(e.effort)}function render(){let weekly=events.filter(e=>inWeek(e.date)),loadTotal=weekly.reduce((n,e)=>n+weight(e),0),limit=sleepAdjustedLimit(load('limit',65)),pct=Math.round(loadTotal/limit*100);$('capacityLimit').value=load('limit',65);$('percent').textContent=pct+'%';$('meter').style.background=`conic-gradient(var(--accent) 0 ${Math.min(100,pct)}%,#ffffff25 ${Math.min(100,pct)}% 100%)`;$('meter').style.setProperty('--used',Math.max(0,Math.min(100,pct))+'%');$('weekly').textContent=weekly.length+' events';$('recovery').textContent=pct>100?'Recovery needed':pct>75?'Plan downtime':'Balanced';renderFourWeeks(limit);renderSleepBudget();$('insight').textContent=pct>100?'⚠️ Your scheduled demands exceed your starting weekly capacity. Consider moving an optional event.':pct>75?'⚠️ You are nearing your planned limit. Protect recovery time.':'🌿 Your schedule has some breathing room.';const card=e=>`<div class="event"><button onclick="cancelEvent('${e.id}')">Cancel</button><button onclick="editEvent('${e.id}')">✏️ Edit</button><b onclick="editEvent('${e.id}')" style="cursor:pointer;text-decoration:underline;text-underline-offset:3px">${esc(e.title)}</b><br><small>${isoDay(e.date)} · ${e.type} · ${e.hours}h</small></div>`;$('upcoming').innerHTML=events.filter(e=>new Date(e.date)>=new Date()).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4).map(card).join('')||'<small>No upcoming events</small>';let view=$('view').value,filter=$('filter').value,filtered=events.filter(e=>filter==='All'||e.type===filter);if(view==='Day')filtered=filtered.filter(e=>new Date(e.date).toDateString()===new Date().toDateString());if(view==='Week')filtered=filtered.filter(e=>inWeek(e.date));if(view==='Month')filtered=filtered.filter(e=>{let d=new Date(e.date),now=new Date();return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear()});let html='';if(view==='Month'){let now=new Date(),last=new Date(now.getFullYear(),now.getMonth()+1,0).getDate();html='<div class="calendar-grid">'+Array.from({length:last},(_,i)=>{let day=i+1,busy=filtered.some(e=>new Date(e.date).getDate()===day);return `<div class="day ${busy?'busy':''}">${day}</div>`}).join('')+'</div>'} $('calendarList').innerHTML=html+filtered.sort((a,b)=>a.date.localeCompare(b.date)).map(card).join('')||'<small>No events for this view</small>';let work=events.filter(e=>e.type==='Work'&&inWeek(e.date));$('workHours').textContent=work.reduce((n,e)=>n+Number(e.hours),0)+' hours this week';$('workList').innerHTML=work.map(card).join('')||'<small>No work shifts this week</small>'}function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function recurringDate(start,frequency,index){
 const d=new Date(start);
 if(frequency==='daily')d.setDate(d.getDate()+index);
 if(frequency==='weekly')d.setDate(d.getDate()+7*index);
 if(frequency==='biweekly')d.setDate(d.getDate()+14*index);
 if(frequency==='monthly'){
  const day=d.getDate();d.setDate(1);d.setMonth(d.getMonth()+index);
  const last=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();d.setDate(Math.min(day,last));
 }
 const pad=n=>String(n).padStart(2,'0');
 return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function addEvent(type){
 const work=type==='Work',title=$(work?'shiftTitle':'eventTitle').value.trim(),date=$(work?'shiftDate':'eventDate').value,
 hours=Number($(work?'shiftHours':'eventHours').value),effort=Number($(work?'shiftEffort':'eventEffort').value);
 if(!title||!date||!Number.isFinite(hours)||hours<=0){alert('Please enter a title, date and valid duration.');return}
 const repeat=work?'none':$('eventRepeat').value;
 const count=repeat==='none'?1:Number($('eventRepeatCount').value);
 if(!Number.isInteger(count)||count<1||count>52||(repeat!=='none'&&count<2)){alert('Choose between 2 and 52 appointments.');return}
 const series='appt'+Date.now().toString(36);
 const pending=Array.from({length:count},(_,i)=>({id:series+'-'+i,title,date:recurringDate(date,repeat,i),hours,effort,type, ...(count>1?{seriesId:series,repeatPattern:repeat}: {})}));
 const limit=load('limit',65),weeklyTotals=new Map();
 for(const e of pending){const key=weekStart(new Date(e.date)).getTime();weeklyTotals.set(key,(weeklyTotals.get(key)||0)+weight(e))}
 const overloaded=[...weeklyTotals].some(([key,extra])=>extra+events.filter(e=>weekStart(new Date(e.date)).getTime()===key).reduce((n,e)=>n+weight(e),0)>limit);
 if(overloaded&&!confirm('⚠️ One or more weeks could be overbooked. Add anyway?'))return;
 events.push(...pending);save('events',events);render();
 if(calendarEnabled()&&(!work||workCalendarSyncEnabled()))pending.forEach(pushLocalEvent);
 else if(!work)alert('Saved in Overbooked. Connect phone calendar to sync appointments.');
}
function cancelEvent(id){let e=events.find(x=>x.id===id);if(!e)return;let reason=prompt('Why are you canceling?\n1 Overwhelmed\n2 Something else came up\n3 Too tired\n4 No longer interested\n5 Other','1');if(reason===null)return;let factor=reason==='1'?prompt('What contributed?\n1 Too many commitments\n2 Work drained energy\n3 Not enough downtime\n4 Stress','1'):null;let log=load('cancellations',[]);log.push({event:e,reason,factor,date:new Date().toISOString()});save('cancellations',log);if(e.calendarEventId&&e.calendarId&&calendarEnabled()&&(e.type!=='Work'||workCalendarSyncEnabled())){if(!confirm('Also delete this event from your connected phone calendar?'))return;OverbookedCalendar.deleteEvent(Number(e.calendarEventId),Number(e.calendarId),e.id)}events=events.filter(x=>x.id!==id);save('events',events);render()}function saveCheckin(){let logs=load('checkins',[]);logs.push({at:new Date().toISOString(),energy:+$('energy').value,stress:+$('stress').value,sleep:$('sleep').value,downtime:$('downtime').value});save('checkins',logs);$('checkinStatus').textContent='Saved locally. Future versions will learn from this history.'}function applyTheme(){theme=$('themeSelect').value;save('theme',theme);document.body.dataset.art=({'Pastel Kawaii':'kawaii','Industrial Dark':'industrial','Strawberry Sweet':'strawberry','Pastel Goth':'goth','Celestial Forest':'forest','Cyberpunk Neon':'cyber','Cozy Cottage':'cottage','Midnight Luxury':'luxury','Retro Pixel':'retro','Ocean Dream':'ocean'})[theme]||'goth';let t=themes[theme],accent=palette[theme]||t[2];palette[theme]=accent;save('palette',palette);for(let [k,v] of Object.entries({'--bg':t[0],'--panel':t[1],'--accent':accent,'--text':t[3],'--muted':t[3]}))document.documentElement.style.setProperty(k,v);renderFavorites()}function selectTheme(t){$('themeSelect').value=t;applyTheme()}function surprise(){selectTheme(faves[Math.floor(Math.random()*faves.length)]||'Pastel Goth')}function renderFavorites(){$('favorites').innerHTML=Object.keys(themes).map(t=>`<label><input type="checkbox" style="width:auto" ${faves.includes(t)?'checked':''} onchange="toggleFavorite('${t}',this.checked)"> ${t}</label>`).join('')}function toggleFavorite(t,on){faves=on?[...new Set([...faves,t])]:faves.filter(x=>x!==t);save('faves',faves)}function saveRotation(){save('rotate',$('rotate').checked)}$('themeSelect').innerHTML=Object.keys(themes).map(t=>`<option>${t}</option>`).join('');$('rotate').checked=load('rotate',false);if($('rotate').checked&&faves.length){let today=new Date().toDateString();if(load('rotatedDate','')!==today){theme=faves[Math.floor(Math.random()*faves.length)];save('rotatedDate',today)}}selectTheme(theme);tab('home');

function setCapacityLimit(){let value=Number($('capacityLimit').value);if(!Number.isFinite(value)||value<5||value>300){alert('Choose a limit between 5 and 300.');return}save('limit',value);render()}
function renderFourWeeks(limit){const start=weekStart(new Date());let totals=[];for(let i=0;i<4;i++){const a=new Date(start);a.setDate(a.getDate()+7*i);const b=new Date(a);b.setDate(b.getDate()+7);totals.push(events.filter(e=>{let d=new Date(e.date);return d>=a&&d<b}).reduce((n,e)=>n+weight(e),0))}const max=Math.max(limit,...totals,1);$('fourWeeks').innerHTML=totals.map((v,i)=>{const pct=Math.round(v/limit*100);return `<div style="margin:13px 0"><div class="row"><span>Week ${i+1}</span><strong style="text-align:right">${pct}%</strong></div><div style="background:#ffffff22;border-radius:12px;overflow:hidden;height:12px"><div style="width:${Math.min(100,v/max*100)}%;height:100%;background:${pct>100?'#ef8787':pct>75?'#e8b86c':'var(--accent)'}"></div></div></div>`}).join('');let high=totals.slice(0,3).filter(v=>v/limit>=.75).length;$('monthInsight').textContent=high===3?'⚠️ Three demanding weeks ahead. Consider making Week 4 a recovery week.':totals.some(v=>v>limit)?'⚠️ At least one upcoming week exceeds your starting capacity.':'🌿 Review the next four weeks before adding more commitments.';}

function localDateTime(ms){const d=new Date(ms),p=n=>String(n).padStart(2,'0');return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+'T'+p(d.getHours())+':'+p(d.getMinutes())}
// Android Calendar Provider integration. Only selected calendars are imported.
const calendarEnabled=()=>!!window.OverbookedCalendar&&load('calendarConnected',false);
const workCalendarSyncEnabled=()=>load('syncWorkToCalendar',false)===true;
function setWorkCalendarSync(on){save('syncWorkToCalendar',!!on);$('workCalendarSync').checked=!!on;$('workSyncStatus').textContent=on?'New and edited work shifts can sync to your selected phone calendar. Existing shifts are not backfilled.':'Work shifts stay in Overbooked. Existing Google Calendar copies are not deleted.';}
let calendarList=[];
function calendarPermissionResult(data){if(!data.granted){$('calendarStatus').textContent='Calendar permission denied';return}save('calendarConnected',true);$('calendarStatus').textContent='Calendar permission granted';OverbookedCalendar.listCalendars()}
function connectCalendar(){if(!window.OverbookedCalendar){$('calendarStatus').textContent='Calendar connection requires the Android app';return}OverbookedCalendar.requestPermission()}
function calendarCalendarsResult(data){if(data.error){$('calendarStatus').textContent=data.error;return}calendarList=data.calendars||[];let selected=load('selectedCalendars',[]);$('calendarChoices').innerHTML=calendarList.map(c=>`<label><input type="checkbox" style="width:auto" ${selected.includes(c.id)?'checked':''} onchange="toggleCalendar(${c.id},this.checked)"> ${esc(c.name)}${c.accountType==='com.google'?' (Google)':''}${c.writable?'':' (read only)'}</label>`).join('')||'<small>No visible calendars found. Check Android account sync settings.</small>';$('calendarStatus').textContent='Choose calendars, then tap Sync now'}
function toggleCalendar(id,on){let selected=load('selectedCalendars',[]);selected=on?[...new Set([...selected,id])]:selected.filter(x=>x!==id);save('selectedCalendars',selected)}
function syncCalendar(){if(!calendarEnabled()){connectCalendar();return}let selected=load('selectedCalendars',[]);if(!selected.length){$('calendarStatus').textContent='Select at least one calendar first';OverbookedCalendar.listCalendars();return}$('calendarStatus').textContent='Reading phone calendar…';OverbookedCalendar.listEvents(JSON.stringify(selected))}
function estimateIntensity(title,hours){let t=String(title).toLowerCase();if(/work|shift|double|overtime|training|exam|moving|travel/.test(t))return 3;if(/appointment|doctor|dentist|meeting|class|shopping|errand/.test(t)||hours>=3)return 2;return 1}
function calendarEventsResult(data){if(data.error){$('calendarStatus').textContent='Sync failed: '+data.error;return}let selected=load('selectedCalendars',[]),external=data.events||[],seen=new Set();let added=0,updated=0;
 for(const c of external){const key=String(c.eventId)+':'+String(c.start);seen.add(key);let e=events.find(x=>x.calendarEventId===c.eventId&&x.calendarStart===c.start&&x.calendarId===c.calendarId);let date=localDateTime(c.start),hours=Math.max(.25,Math.round((c.end-c.start)/900000)/4);if(e){if(e.title!==c.title||e.date!==date||e.hours!==hours){e.title=c.title||'Untitled';e.date=date;e.hours=hours;updated++}}else{events.push({id:'cal'+c.calendarId+'_'+c.eventId+'_'+c.start,title:c.title||'Untitled',date,hours,effort:estimateIntensity(c.title,hours),type:'Personal',calendarId:c.calendarId,calendarEventId:c.eventId,calendarStart:c.start,imported:true});added++}}
 // Missing external events are retained, not deleted, to avoid accidental data loss.
 save('events',events);render();$('calendarStatus').textContent=`Synced: ${added} imported, ${updated} updated. Missing events are kept for safety.`;
}
function pushLocalEvent(e){if(e.type==='Work'&&!workCalendarSyncEnabled())return;let chosen=load('selectedCalendars',[]),target=calendarList.find(c=>chosen.includes(c.id)&&c.writable&&c.accountType==='com.google')||calendarList.find(c=>chosen.includes(c.id)&&c.writable);if(!target){$('calendarStatus').textContent='Event saved locally. Select a writable calendar and sync.';return}let start=new Date(e.date).getTime();OverbookedCalendar.saveEvent(JSON.stringify({localId:e.id,calendarId:target.id,title:e.title,start,end:start+e.hours*3600000}))}
function calendarSaveResult(data){if(!data.ok){$('calendarStatus').textContent='Event saved locally; calendar write failed: '+(data.error||'Unknown error');return}let e=events.find(x=>x.id===data.localId);if(e){e.calendarEventId=data.eventId;e.calendarId=(calendarList.find(c=>load('selectedCalendars',[]).includes(c.id)&&c.writable&&c.accountType==='com.google')||calendarList.find(c=>load('selectedCalendars',[]).includes(c.id)&&c.writable)||{}).id;e.calendarStart=new Date(e.date).getTime();save('events',events)}$('calendarStatus').textContent='Event saved to phone calendar'}
function calendarDeleteResult(data){$('calendarStatus').textContent=data.ok?'Calendar event deleted':'Calendar deletion failed: '+(data.error||'Unknown error')}
if(window.OverbookedCalendar&&load('calendarConnected',false))OverbookedCalendar.listCalendars();

// Edit appointments and work shifts in place, preserving their calendar link.
let editingEventId=null;
function editEvent(id){
 const e=events.find(item=>item.id===id);if(!e)return;
 editingEventId=id;
 $('editTitle').value=e.title;
 $('editDate').value=e.date.slice(0,16);
 $('editHours').value=e.hours;
 $('editEffort').value=e.effort;
 $('editType').value=e.type;
 $('editDialog').classList.remove('hidden');
}
function closeEventEditor(){$('editDialog').classList.add('hidden');editingEventId=null}
function saveEditedEvent(){
 const e=events.find(item=>item.id===editingEventId);if(!e)return;
 const title=$('editTitle').value.trim(),date=$('editDate').value,hours=Number($('editHours').value),effort=Number($('editEffort').value),type=$('editType').value;
 if(!title||!date||!Number.isFinite(hours)||hours<=0){alert('Enter a title, date, and valid duration.');return}
 const projected=events.filter(item=>item.id!==e.id&&weekStart(new Date(item.date)).getTime()===weekStart(new Date(date)).getTime()).reduce((n,item)=>n+weight(item),0)+hours*effort;
 if(projected>load('limit',65)&&!confirm('⚠️ This could overbook that week. Save anyway?'))return;
 Object.assign(e,{title,date,hours,effort,type});save('events',events);closeEventEditor();render();
 if(e.type==='Work'&&!workCalendarSyncEnabled())return;
 if(e.calendarEventId&&e.calendarId&&calendarEnabled()){
  const start=new Date(e.date).getTime();
  OverbookedCalendar.saveEvent(JSON.stringify({localId:e.id,calendarId:e.calendarId,eventId:e.calendarEventId,title:e.title,start,end:start+e.hours*3600000}));
 }else if(!e.calendarEventId&&calendarEnabled())pushLocalEvent(e);
}

// Weekly and temporary shifts, saved as editable instances.
function addTemporaryShift(){
 const title=$('tempTitle').value.trim(),date=$('tempDate').value,hours=Number($('tempHours').value),effort=Number($('tempEffort').value);
 if(!title||!date||hours<=0){alert('Enter a title, date and valid duration.');return}
 const e={id:'tmp'+Date.now().toString(36),title,date,hours,effort,type:'Work',temporary:true};
 const projected=events.filter(x=>weekStart(new Date(x.date)).getTime()===weekStart(new Date(date)).getTime()).reduce((n,x)=>n+weight(x),0)+weight(e);
 if(projected>load('limit',65)&&!confirm('⚠️ This could overbook that week. Add anyway?'))return;
 events.push(e);save('events',events);render();if(calendarEnabled()&&workCalendarSyncEnabled())pushLocalEvent(e);
}
function addWeeklyShift(){
 const title=$('shiftTitle').value.trim(),date=$('shiftDate').value,hours=Number($('shiftHours').value),effort=Number($('shiftEffort').value);
 if(!title||!date||hours<=0){alert('Enter a title, start date and valid duration.');return}
 const start=new Date(date),group='weekly'+Date.now().toString(36),pending=[];
 for(let i=0;i<52;i++){const d=new Date(start);d.setDate(start.getDate()+7*i);const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0'),h=String(d.getHours()).padStart(2,'0'),min=String(d.getMinutes()).padStart(2,'0');pending.push({id:group+'-'+i,title,date:`${y}-${m}-${day}T${h}:${min}`,hours,effort,type:'Work',weeklyGroup:group})}
 if(!confirm('Add this shift every week for the next 52 weeks? You can edit individual shifts afterward.'))return;
 events.push(...pending);save('events',events);render();
 showShiftNotice('✓ Weekly schedule saved');
 if(calendarEnabled()&&workCalendarSyncEnabled())queueWeeklyCalendarSync(pending);
}

// Sync each weekly instance through Android Calendar Provider, with bounded writes.
let weeklySyncQueue=[],weeklySyncBusy=false,weeklySyncTimer=null;
function showShiftNotice(message){
 let el=$('shiftNotice');if(!el)return;
 el.textContent=message;el.style.display='block';
 clearTimeout(weeklySyncTimer);
 weeklySyncTimer=setTimeout(()=>{el.style.display='none'},4500);
}
function queueWeeklyCalendarSync(shifts){
 const chosen=load('selectedCalendars',[]);
 const target=calendarList.find(c=>chosen.includes(c.id)&&c.writable&&c.accountType==='com.google')||calendarList.find(c=>chosen.includes(c.id)&&c.writable);
 if(!target){showShiftNotice('✓ Saved in Overbooked. Select a writable phone calendar to sync.');return}
 weeklySyncQueue.push(...shifts.map(e=>({localId:e.id,calendarId:target.id,title:e.title,start:new Date(e.date).getTime(),end:new Date(e.date).getTime()+e.hours*3600000})));
 processWeeklySync();
}
function processWeeklySync(){
 if(weeklySyncBusy||!weeklySyncQueue.length||!calendarEnabled())return;
 weeklySyncBusy=true;
 const next=weeklySyncQueue[0];
 try{OverbookedCalendar.saveEvent(JSON.stringify(next))}
 catch(err){weeklySyncBusy=false;showShiftNotice('Calendar sync paused. Shifts are saved in Overbooked.');}
}
// Wrap the existing native result handler to continue the queue only after a write finishes.
const previousCalendarSaveResult=calendarSaveResult;
calendarSaveResult=function(data){
 previousCalendarSaveResult(data);
 if(weeklySyncBusy&&weeklySyncQueue.length&&String(data.localId)===String(weeklySyncQueue[0].localId)){
   if(data.ok){weeklySyncQueue.shift();weeklySyncBusy=false;
     if(weeklySyncQueue.length){$('calendarStatus').textContent='Syncing weekly shifts: '+weeklySyncQueue.length+' remaining';setTimeout(processWeeklySync,100)}
     else {showShiftNotice('✓ Weekly shifts synced to phone calendar');$('calendarStatus').textContent='Weekly shifts synced to phone calendar'}
   }else{weeklySyncBusy=false;showShiftNotice('Weekly shifts saved. Calendar sync stopped; check Calendar settings.');}
 }
};

// Sleep Budget: separate clock availability from energy-adjusted recommendations.
function sleepSettings(){return load('sleepPlan',{goal:8,bed:'22:00',wake:'06:00'})}
function sleepLog(){return load('sleepHistory',[])}
function sleepDeficit(){const plan=sleepSettings(),logs=sleepLog().slice(-3);if(!logs.length)return 0;return Math.min(12,logs.reduce((sum,x)=>sum+Math.max(0,plan.goal-Number(x.hours||0)),0))}
function sleepPenalty(){return Math.min(.45,sleepDeficit()*.06)}
function sleepAdjustedLimit(base){return Math.max(5,base*(1-sleepPenalty()))}
function saveSleepPlan(){const goal=Number($('sleepGoal').value),bed=$('sleepBed').value,wake=$('sleepWake').value;if(!Number.isFinite(goal)||goal<4||goal>12||!bed||!wake){$('sleepStatus').textContent='Enter a goal between 4 and 12 hours and both times.';return}save('sleepPlan',{goal,bed,wake});$('sleepStatus').textContent='✓ Sleep schedule saved';render()}
function recordSleep(){const hours=Number($('sleepActual').value);if(!Number.isFinite(hours)||hours<0||hours>24){$('sleepStatus').textContent='Enter a number between 0 and 24 hours.';return}const day=new Date();day.setDate(day.getDate()-1);const key=day.toISOString().slice(0,10);let logs=sleepLog().filter(x=>x.day!==key);logs.push({day:key,hours});logs.sort((a,b)=>a.day.localeCompare(b.day));save('sleepHistory',logs.slice(-90));$('sleepStatus').textContent='✓ Sleep logged. Capacity recalculated.';render()}
function sleepIntervalFor(date){const p=sleepSettings();const [bh,bm]=p.bed.split(':').map(Number),[wh,wm]=p.wake.split(':').map(Number);const start=new Date(date);start.setHours(bh,bm,0,0);const end=new Date(date);end.setHours(wh,wm,0,0);if(end<=start)end.setDate(end.getDate()+1);return [start,end]}
function overlapHours(a,b,c,d){return Math.max(0,Math.min(b,d)-Math.max(a,c))/3600000}
function renderSleepBudget(){const p=sleepSettings();if($('sleepGoal')){$('sleepGoal').value=p.goal;$('sleepBed').value=p.bed;$('sleepWake').value=p.wake}const now=new Date(),end=new Date(now);end.setHours(24,0,0,0);let sleep=0;for(let offset=-1;offset<=0;offset++){const day=new Date(now);day.setDate(day.getDate()+offset);const [a,b]=sleepIntervalFor(day);sleep+=overlapHours(now,end,a,b)}let busy=0;events.forEach(e=>{const a=new Date(e.date),b=new Date(a.getTime()+Number(e.hours||0)*3600000);if(!Number.isNaN(a.getTime()))busy+=overlapHours(now,end,a,b)});const free=Math.max(0,(end-now)/3600000-sleep-busy),penalty=sleepPenalty(),usable=free*(1-penalty);$('freeHours').textContent=free.toFixed(1)+'h';$('usableHours').textContent=usable.toFixed(1)+'h';$('sleepSummary').textContent=`Sleep goal ${p.goal}h · ${p.bed}–${p.wake} · ${Math.round(penalty*100)}% planning reduction based on recent logged sleep. ${sleepDeficit().toFixed(1)}h shortfall across the last 3 logs.`}

// Work shifts are private to Overbooked unless explicitly enabled.
if($('workCalendarSync'))setWorkCalendarSync(workCalendarSyncEnabled());
